fx_version "cerulean"
game "gta5"
lua54 "yes"

author 'xandiir'

client_scripts {
	'client.lua',
}

server_scripts {
	'server.lua',
}

shared_scripts {
	'@ox_lib/init.lua'
}

